#include "comandos.h"

//Estrutura
struct com {
	int command;
	int idConta;
	int valor;
};

/* Declaracao das variaveis globais */
// Lista de tarefas
pthread_t th_list[MAX_THREADS];

// Buffer de comandos
comando_t com_buffer[MAX_COMANDOS];

// Semaforos
sem_t pode_criar, pode_tratar;

// Indices do buffer (produtor / consumidor)
int ptr_tratacoms, ptr_criacoms;

// Trincos (produtor / consumidor)
//         (Contas) 
pthread_mutex_t trico_tr, trico_cr;
pthread_mutex_t trinco_contas[NUM_CONTAS];


// Cabeca da lista ligada de processos
Node sims = NULL;  

int FLAG_TERM = 0; //Se esta a terminar processos

/*
* Inicializa todas as variaveis globais
* 
*
*/

//pthread_create devolve 0 - success
//						 1 - 

int initComandos() {
	int i;
	// Inicilizacao das threads
	for (i=0; i < MAX_THREADS; i++) {
		if(pthread_create(&th_list[i], 0, buscaComando,(void*)com_buffer))
			return -1;
	}

	// Inicializacao dos trincos
	for(i=0; i < NUM_CONTAS; i++) {
		if(pthread_mutex_init(&trinco_contas[i], 0))
			return -1;
	}
	if(pthread_mutex_init(&trico_cr, 0))
		return -1;
	if(pthread_mutex_init(&trico_tr, 0))
		return -1;

	// Inicializacao dos semaforos
	if(sem_init(&pode_criar, 0, MAX_COMANDOS))
		return -1;

	if(sem_init(&pode_tratar, 0, 0))
		return -1;

	// Set dos indices a zer0
	ptr_tratacoms = 0; 
	ptr_criacoms =  0;

	return 0;
}



/*
* Termina os fios de execucao
*/
void closeThreads(int force) {
	int i;
	// Espera que cada tarefa encerre
	for (i=0; i < MAX_THREADS; i++) {
		pthread_join(th_list[i], NULL);
	}
	// Termina os processos filho
	stopNodes(sims, force);
}

/*
* Espera que exista um comando para tratar
* e trata-o
*/
void * buscaComando() {
	int curProcess = 0;

	while(1337) {
		comando_t com;
		
		sem_wait(&pode_tratar);          // Espera que exista um comando
		pthread_mutex_lock(&trico_tr);   // Fecha o acesso de outras tarefas

		com = com_buffer[ptr_tratacoms];
		ptr_tratacoms = (ptr_tratacoms+1) % MAX_COMANDOS;

		pthread_mutex_unlock(&trico_tr); // Reabre 
		sem_post(&pode_criar);			 // Assinala que pode produzir

		trataComando(com, &curProcess);  // Trata o comando
	}
}


/*
* Executa o comando
*/
void trataComando(comando_t com, int * curProcess) {
	
	switch(com.command) {
		case OP_DEBITAR:{
			pthread_mutex_lock(&trinco_contas[com.idConta]);
			if (debitar (com.idConta, com.valor) < 0)
	           printf("%s(%d, %d): Erro\n\n", COMANDO_DEBITAR, com.idConta, com.valor);
            else
                printf("%s(%d, %d): OK\n\n", COMANDO_DEBITAR, com.idConta, com.valor);
			pthread_mutex_unlock(&trinco_contas[com.idConta]);
			break;
		}
		case OP_CREDITAR:{
			pthread_mutex_lock(&trinco_contas[com.idConta]);
			if (creditar (com.idConta, com.valor) < 0)
                printf("%s(%d, %d): Erro\n\n", COMANDO_CREDITAR, com.idConta, com.valor);
            else
                printf("%s(%d, %d): OK\n\n", COMANDO_CREDITAR, com.idConta, com.valor);
			pthread_mutex_unlock(&trinco_contas[com.idConta]);
			break;
		}
		case OP_LER_SALDO: {
			pthread_mutex_lock(&trinco_contas[com.idConta]);
			com.valor = lerSaldo (com.idConta);
            if (com.valor < 0)
                printf("%s(%d): Erro.\n\n", COMANDO_LER_SALDO, com.idConta);
            else
                printf("%s(%d): O saldo da conta é %d.\n\n", COMANDO_LER_SALDO, com.idConta, com.valor);
			pthread_mutex_unlock(&trinco_contas[com.idConta]);
			break;
		}
		case OP_SIMULAR: {

			pid_t cpid;
            cpid = fork();

            if (cpid == 0) {
                //codigo do filho
                simular(com.valor);
            } else {
                //codigo do pai
                sims = createNode(sims, cpid);
            }
		}
		case OP_SAIR: {
            pthread_exit(NULL);
		}
	}
}

void criaComando(int command, int conta, int valor) {
	sem_wait(&pode_criar);
	pthread_mutex_lock(&trico_cr);

	com_buffer[ptr_criacoms].command = command;
	com_buffer[ptr_criacoms].idConta = conta;
	com_buffer[ptr_criacoms].valor = valor;
	ptr_criacoms = (ptr_criacoms+1) % MAX_COMANDOS;

	pthread_mutex_unlock(&trico_cr);
	sem_post(&pode_tratar);
}