#include "i-banco-terminal.h"

int numargs;
char *args[MAXARGS+1];
char buffer[BUFFER_SIZE];
char out[BUFFER_SIZE];
char in[BUFFER_SIZE];

int servidorExiste = 1;

int main(int argc, char * argv[]) {
	char msg[BUFFER_SIZE];
	int pid;
    time_t start, stop;
    
	comando_t com;

	if(!init(&pid, argc, argv)){
		printf("Deu erro a iniciar\n");
        perror("teste\n");
		exit(EXIT_FAILURE);
	}

	while (1) {
		if(leComando(pid, &com)) {
            if(servidorExiste) {
                sendCommand(out, &com, COM_SIZE);
                time(&start);
                readFromPipe(in, msg);
                time(&stop);
                printf("%sPing: %5.2fs\n\n", msg, difftime(stop, start));
            }  
        }
	}
}

int init(int *pid, int argc, char * argv[]) {
	
    char success[BUFFER_SIZE];
    signal(SIGUSR1, fechaTerm);

	*pid = getpid();

    if(argc < 2)
        return 0;

	sprintf(out, "/tmp/%s", argv[1]);

	sprintf(in, "%s%d", PATH_PIPE_TERM, *pid);
	
	if(createPipe(in))
		return 0;

    comando_t com = geraComando(*pid, OP_NEW_TERM, KEY, *pid, 0);
	if(sendCommand(out, &com, COM_SIZE))
		return 0;

	if(readFromPipe(in, success))
		return 0;

	if(!strcmp(success, "Servidor cheio\n")) {
		printf("%s", success);
		return 0;
	}

    printf("%s", success);
	return 1;
}

/*rotina de interrupcao SIGUSR1*/
void fechaTerm () {
    servidorExiste = 0;
}

int leComando(int pid, comando_t * com) {

    printf("Insira Comando: ");
	numargs = readLineArguments(args, MAXARGS+1, buffer, BUFFER_SIZE);
        /* EOF (end of file) do stdin ou comando "sair" */

        if (numargs < 0 ||
	        (numargs > 0 && numargs == 1 && (strcmp(args[0], COMANDO_SAIR)==0)))  {
            *com = geraComando(pid, OP_SAIR, 0, 0, 0);
        	return 1;  
        }
        
        else if (numargs > 0 && numargs == 2 && (strcmp(args[0], COMANDO_SAIR) == 0) && (strcmp(args[1], COMANDO_AGORA) == 0)) {
            *com = geraComando(pid, OP_SAIR_AGORA, 0, 0, 0);
            return 1;
        }

        else if (numargs > 0 && numargs == 1 && (strcmp(args[0], COMANDO_SAIR_TERMINAL) == 0)) {
            if (!servidorExiste) {
                if(destroyPipe(out))
                    exit(EXIT_FAILURE);
            }
            if(destroyPipe(in))
                exit(EXIT_FAILURE);
            exit(EXIT_SUCCESS);
        }

        else if (numargs == 0)
            /* Nenhum argumento; ignora e volta a pedir */
            return 0;

        /* Debitar */
        else if (strcmp(args[0], COMANDO_DEBITAR) == 0) {
            int idConta, valor;
            if (numargs < 3) {
                printf("%s: Sintaxe inválida, tente de novo.\n", COMANDO_DEBITAR);
	           return 0;
            }

            idConta = atoi(args[1]);
            valor = atoi(args[2]);

            *com = geraComando(pid, OP_DEBITAR, idConta, 0, valor);
            return 1;
        }

        /* Creditar */
        else if (strcmp(args[0], COMANDO_CREDITAR) == 0) {
            int idConta, valor;
            if (numargs < 3) {
                printf("%s: Sintaxe inválida, tente de novo.\n", COMANDO_CREDITAR);
                return 0;
            }

            idConta = atoi(args[1]);
            valor = atoi(args[2]);

            *com = geraComando(pid, OP_CREDITAR, idConta, 0, valor);
            return 1;
        }

        /* Ler Saldo */
        else if (strcmp(args[0], COMANDO_LER_SALDO) == 0) {
            int idConta;

            if (numargs < 2) {
                printf("%s: Sintaxe inválida, tente de novo.\n\n", COMANDO_LER_SALDO);
                return 0;
            }
            idConta = atoi(args[1]);
            *com = geraComando(pid, OP_LER_SALDO, idConta, 0, 0);
            return 1;
        }

        /* Simular */
        else if (strcmp(args[0], COMANDO_SIMULAR) == 0) {

            int i;
            if ( ( i = atoi(args[1]) ) == 0 && strcmp(args[1], "0") ) {
                printf("Simular apenas aceita numeros %s\n", args[1]);
                return 0;
            }

            *com = geraComando(pid, OP_SIMULAR, 0, 0, i);
            return 1;
        }

        //Tranferencia
        else if (strcmp(args[0], COMANDO_TRANSFERENCIA) == 0) {
            int idConta, idConta2, valor;
            if (numargs < 4) {
                printf("%s: Sintaxe inválida, tente de novo.\n", COMANDO_TRANSFERENCIA);
               return 0;
            }

            idConta = atoi(args[1]);
            idConta2 = atoi(args[2]);
            valor = atoi(args[3]);

            *com = geraComando(pid, OP_TRANSFERIR, idConta, idConta2, valor);
            return 1;
        }

        else {
            printf("Comando desconhecido. Tente de novo.\n");
            return 0;
        }
}

comando_t geraComando(int pid, int command, int idConta, int idConta2, int valor) {
	comando_t com;

	com.pid      = pid;
	com.command  = command;
	com.idConta  = idConta;
	com.idConta2 = idConta2;
	com.valor    = valor;

	return com;
} 
