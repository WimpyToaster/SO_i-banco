#ifndef _COM_
#define _COM_

#include <sys/types.h>
#include "LinkedList.h"
#include "contas.h"
#include "wrappers.h"
#include "Out.h"
#include "MACROS/MacrosComandos.h"

int initComandos();
void termComandos(int force);
void closeThreads(int force);
void * buscaComando();
int trataComando(comando_t com, int * curProcess);
void criaComando(comando_t);
void aumentaContador();
void decrementaContador();


#endif