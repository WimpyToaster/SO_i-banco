#ifndef _MACRO_CONTAS_
#define _MACRO_CONTAS_

#define NUM_CONTAS 10
#define TAXAJURO 0.1
#define CUSTOMANUTENCAO 1
#define FORMULA(A) ( (A * (1 + TAXAJURO) - CUSTOMANUTENCAO) )
#define MAX(X,Y) ((X > Y) ? X : Y)
#define atrasar() sleep(ATRASO)

#define ATRASO 1

#endif