#ifndef _MACRO_OUT_
#define _MACRO_OUT_

#define RES_BUFF 100
//#define PERMISSIONS (S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP | S_IROTH | S_IWOTH)
#define PERMISSIONS	 0666

#endif
