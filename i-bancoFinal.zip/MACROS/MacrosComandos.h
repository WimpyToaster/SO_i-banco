#ifndef _MACROS_COMANDOS_
#define _MACROS_COMANDOS_

#define OP_DEBITAR 0
#define OP_CREDITAR 1
#define OP_LER_SALDO 2
#define OP_SIMULAR 3
#define OP_TRANSFERIR 4
#define OP_SAIR 5
#define OP_SAIR_AGORA 6
#define OP_NEW_TERM 7

#define COMANDO_DEBITAR "debitar"
#define COMANDO_CREDITAR "creditar"
#define COMANDO_LER_SALDO "lerSaldo"
#define COMANDO_SIMULAR "simular"
#define COMANDO_SAIR "sair"
#define COMANDO_AGORA "agora"
#define COMANDO_TRANSFERENCIA "transferir"
#define COMANDO_SAIR_TERMINAL "sair-terminal"
#define COMANDO_TERMINAL "t"

#define PATH_PIPE_SERVER "/tmp/i-banco-pipe"
#define PATH_PIPE_TERM "/tmp/i-banco-t-"

#define LOG_INIT "Logs\nTID: comando\n"
#define MAX_TERM 4

#define COM_SIZE (sizeof(comando_t))

#define KEY 1234

#define MAX_THREADS 3
#define MAX_COMANDOS (MAX_THREADS * 2)

typedef struct com {
	int pid;
	int command;
	int idConta;
	int idConta2;
	int valor;
} comando_t;

#endif
