#include "contas.h"

int FLAG_SIM = 0;
int contasSaldos[NUM_CONTAS];


int contaExiste(int idConta) {
    return (idConta > 0 && idConta <= NUM_CONTAS);
}

void inicializarContas() {
    int i;
    for (i=0; i<NUM_CONTAS; i++)
        contasSaldos[i] = 0;
}

int debitar(int idConta, int valor) {
    atrasar();
    if (!contaExiste(idConta))
        return 0;
    if (valor < 0 || contasSaldos[idConta - 1] < valor)
        return 0;
    atrasar();
    contasSaldos[idConta - 1] -= valor;
    return 1;
}

int creditar(int idConta, int valor) {
    atrasar();
    if (!contaExiste(idConta))
        return 0;
    if (valor < 0)
        return 0;
    contasSaldos[idConta - 1] += valor;
    return 1;
}

int lerSaldo(int idConta) {
    atrasar();
    if (!contaExiste(idConta))
        return -1;
    return contasSaldos[idConta - 1];
}


/****************************************
* Muda a flag FLAG para 1               *
* NOTA: Usada no tratamento de sinais   *
*       da funcao simular               *
****************************************/
void mudaFlag() {
    FLAG_SIM = 1;
}

/****************************************
* Simula o valor de conta ao final de   *
* "numAnos"                             *
* Recebe: Numero de anos a simular      *
* NOTA: A comentario esta implementada  *
*       uma maneira alternativa de      *
*       tratar as simuacoes (ficheiros) *
****************************************/
int simular(int numAnos) {
    if (numAnos < 0) {
        return 0;
    }

    signal(SIGUSR1, mudaFlag);
    
    int i,j, contas[NUM_CONTAS];

    for(i=0; i <= numAnos; i++){
        if(FLAG_SIM) {
                printf("Simulacao terminou por sinal\n");
                exit(EXIT_SUCCESS);
        }
        printf("SIMULACAO: Ano %d\n=================\n", i);
        for(j=0; j < NUM_CONTAS; j++) {
            if(i == 0) {
                contas[j] = lerSaldo(j+1);
                printf("Conta %d, Saldo %d\n", j+1, contas[j]);
            }
            else {
                contas[j] = MAX(FORMULA(contas[j]), 0);
                printf("Conta %d, Saldo %d\n", j+1, contas[j]);
                sleep(1);
            }
            
        }
        printf("\n");
    }
    return 1;
}