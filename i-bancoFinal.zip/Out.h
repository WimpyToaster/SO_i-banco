#ifndef _OUT_
#define _OUT_

#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <errno.h>
#include "wrappers.h"

#define RES_BUFF 100
#define PERMISSIONS (S_IRWXU | S_IRWXG | S_IRWXO)
#define MAX_PIPES 20

int writeToFile(const char*,char*);
int readFromFile(const char*,char*);
int createDir(const char*);
int writeToPipe(const char*,char*);
int readFromPipe(const char*,char*);
int sendCommand(const char*,void*,int);
int receiveCommand(const char*,void*,int);
int directOut(char*);
int directIn(int);
int createPipe(const char*);
int createFile(const char*);
int openPipe(const char*,int);
int destroyPipe(const char*);

#endif