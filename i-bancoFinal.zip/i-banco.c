/*
// Projeto SO - exercicio 1, version 1
// Sistemas Operativos, DEI/IST/ULisboa 2016-17
*/


#include "comandos.h"


#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#define MAXPROCC 20

#define TH_BUFFER 3



int main () {

    comando_t comando;
    inicializarContas();
    if(initComandos() == -1) {
        printf("Inicializacao dos comandos correu mal\n");
        return 1;
    }

    while (1) {
        receiveCommand(PATH_PIPE_SERVER, &comando, COM_SIZE);
        if (comando.command == OP_SAIR) {
            termComandos(NORMAL);
            exit(EXIT_SUCCESS);
        } else if (comando.command == OP_SAIR_AGORA) {
            termComandos(NOFORCE);
            exit(EXIT_SUCCESS);
        } else
            criaComando(comando);
        }
    return 0;
}        
