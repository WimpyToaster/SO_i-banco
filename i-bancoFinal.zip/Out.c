#include "Out.h"

int currentOpenFd = 1;
int numPipes[MAX_PIPES];

//opens writes closes
int writeToFile(const char * pathName, char * data) {
	int res = open(pathName, O_WRONLY | O_APPEND, PERMISSIONS);
	if (res == -1)
		return 1;
	if (write(res, data, strlen(data) < 0))
		return 1;
	if(close(res))
		return 1;
	return 0;
}

int readFromFile(const char * pathName, char * data) {
	int res = open(pathName, O_RDONLY, PERMISSIONS);
	if (res == -1)
		return 0;
	if(read(res, data, RES_BUFF) < 0)
		return 1;
	if(close(res))
		return 1;
	return 0;
}

int createFile(const char * pathName) {
	int res = open(pathName, O_RDWR | O_CREAT | O_EXCL, PERMISSIONS);
	if (res == -1)
		return 1;
	if (close(res))
		return 1;
	return 0;
}

int writeToPipe(const char * pathName, char * data) {
	int res = open(pathName, O_WRONLY, PERMISSIONS);
	if (res == -1){
		if (errno != EEXIST){
			return 1;
		} else
		return -1;
	}
	if (write(res, data, RES_BUFF) < 0)
		return 1;
	if(close(res))
		return 1;
	return 0;
}

int readFromPipe(const char * pathName, char * data) {
	int res = open(pathName, O_RDONLY, PERMISSIONS);
	if (res == -1)
		return 1;
	if(read(res, data, RES_BUFF) < 0)
		return 1;
	if(close(res))
		return 1;
	return 0;
}

int createDir(const char * path) {
	if(mkdir(path, PERMISSIONS))
		if (errno != EEXIST)
			return 1;
	return 0;
}

int sendCommand(const char * path, void * com, int size) {
	int res = open(path, O_WRONLY, PERMISSIONS);
	if (res == -1)
		return 1;
	if (write(res, com, size) < 0)
		return 1;
	if (close(res))
		return 1;
	return 0;
}

int receiveCommand(const char* path, void * com, int size) {
	int res = open(path, O_RDONLY, PERMISSIONS);
	if (res == -1)
		return 1;
	if (read(res, com, size) < 0);
		return 1;
	if (close(res))
		return 1;
	return 0;
}

//close old, open new, redirect
int directOut(char * str) {
	if(currentOpenFd != 1)
		close(currentOpenFd);
	int res = open(str, O_CREAT | O_RDWR, PERMISSIONS);
	if (res == -1)
		return 1;
	if(dup2(res, 1) < 0)
		return 1;
	currentOpenFd = res;
	return 0;
}

/*fzr verificacoess	*/
int directIn(int fd) {
	if(dup2(fd, 0) < 0)
		return 1;
	return 0;
}

int closeOut() {
	if (close(currentOpenFd))
		return 1;
	return 0;
}

/*  */
int createPipe(const char * pipeName) {
	int i = mkfifo(pipeName, PERMISSIONS);
	if (i != 0)
		if(errno != EEXIST)
			return 1;
	return 0;
}

/*true false*/
int openPipe(const char * pipeName, int flags) {
	int i;
	if((i = open(pipeName, flags)) < 0)
		return 1;
	return i;

}

int closePipe(int pipeId) {
	if(close(pipeId))
		return 1;
	return 0;
}

int destroyPipe(const char * path) {
	if (unlink(path))
		if (errno != ENOENT)
			return 1;
	return 0;
}
