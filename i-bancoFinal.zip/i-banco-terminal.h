#ifndef _TERM_
#define _TERM_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <time.h>

#include "Out.h"
#include "commandlinereader.h"

#include "MACROS/MacrosComandos.h"

#define MAXARGS 4
#define BUFFER_SIZE 100

#define KEY 1234

int init(int*,int ,char**);
void fechaTerm ();
int leComando(int, comando_t*);
comando_t geraComando(int, int, int, int, int);

#endif
